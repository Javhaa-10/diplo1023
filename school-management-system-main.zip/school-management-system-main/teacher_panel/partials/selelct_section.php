<option value="А">A</option>
<option value="Б">Б</option>
<option value="В">В</option>